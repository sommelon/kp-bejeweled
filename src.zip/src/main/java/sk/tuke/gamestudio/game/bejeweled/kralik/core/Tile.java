package sk.tuke.gamestudio.game.bejeweled.kralik.core;

public class Tile {
    private Tile tileShape;

    public Tile(){

    }

    public Tile getTileShape() {
        return tileShape;
    }

    public void setTileShape(Tile tile) {
        this.tileShape = tile;
    }
}
