package sk.tuke.gamestudio.game.bejeweled.kralik;

import sk.tuke.gamestudio.game.bejeweled.kralik.consoleui.ConsoleUI;

public class Bejeweled {
    public static void main(String[] args) {
        ConsoleUI ui = new ConsoleUI();

        ui.run();
    }
}
