package sk.tuke.gamestudio.game.bejeweled.kralik.core;

public enum GameState {
    PLAYING, NO_POSSIBLE_MOVES, TIME_OUT;
}