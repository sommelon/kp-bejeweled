package sk.tuke.gamestudio.game.bejeweled.kralik.entity;

public enum CommandType {
    REMOVE, FILL, DROP
}
