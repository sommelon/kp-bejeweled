package sk.tuke.gamestudio.game.bejeweled.kralik.shapes;

import sk.tuke.gamestudio.game.bejeweled.kralik.core.Tile;

public class Hexagon extends Tile {
    public Hexagon() {
        this.setTileShape(this);
    }
}
