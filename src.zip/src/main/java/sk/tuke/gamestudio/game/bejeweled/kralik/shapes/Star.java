package sk.tuke.gamestudio.game.bejeweled.kralik.shapes;

import sk.tuke.gamestudio.game.bejeweled.kralik.core.Tile;

public class Star extends Tile {
    public Star() {
        this.setTileShape(this);
    }
}
