package sk.tuke.gamestudio.game.bejeweled.kralik.shapes;

import sk.tuke.gamestudio.game.bejeweled.kralik.core.Tile;

public class Circle extends Tile {
    public Circle() {
        this.setTileShape(this);
    }
}
