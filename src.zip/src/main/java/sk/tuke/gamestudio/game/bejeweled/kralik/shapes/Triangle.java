package sk.tuke.gamestudio.game.bejeweled.kralik.shapes;

import sk.tuke.gamestudio.game.bejeweled.kralik.core.Tile;

public class Triangle extends Tile {
    public Triangle() {
        this.setTileShape(this);
    }
}
